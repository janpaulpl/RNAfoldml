let names = [ "Songyu Ye"; "Jan-Paul Vincent Ramos"; "Inle Bush" ]
let hours_worked = 50